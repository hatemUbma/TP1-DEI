/**
 * EcoSDK — SDK client officiel d'EcoMarketplace (v1.0.0)
 *
 * Objectif : permettre à un site marchand d'envoyer ses données d'émissions
 * carbone en 3 lignes de code :
 *
 *   const { EcoSDK } = require('./ecosdk');
 *   const eco = new EcoSDK({ apiKey: 'mch_live_99x821a' });
 *   await eco.trackPurchase({ orderId: 'ORD-1', items: [{ category: 'food', weightKg: 2 }] });
 *
 * Ce que le SDK masque au développeur marchand :
 *   - l'authentification (header X-API-Key)         -> sécurité / DX
 *   - la sérialisation JSON et les en-têtes HTTP    -> moins de code répétitif
 *   - les erreurs réseau, timeouts, 429, 5xx        -> retries avec backoff exponentiel
 *   - la version de l'API (/v1)                     -> stabilité face aux breaking changes
 *
 * Aucune dépendance externe : utilise le fetch natif de Node.js >= 18.
 */

'use strict';

const SDK_VERSION = '1.0.0';
const DEFAULT_BASE_URL = 'http://localhost:8000';

// ---------------------------------------------------------------------------
// Hiérarchie d'erreurs typées
// Le marchand peut faire `err instanceof EcoAuthError` au lieu de parser des
// codes HTTP : c'est une partie importante de la Developer Experience.
// ---------------------------------------------------------------------------

class EcoSDKError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = this.constructor.name;
    this.status = details.status;      // code HTTP éventuel
    this.cause = details.cause;        // erreur d'origine éventuelle
    this.attempts = details.attempts;  // nombre de tentatives effectuées
  }
}

/** Clé API absente, invalide ou révoquée (HTTP 401/403). Inutile de réessayer. */
class EcoAuthError extends EcoSDKError {}

/** Données refusées : validation locale ou HTTP 400/422. Inutile de réessayer. */
class EcoValidationError extends EcoSDKError {}

/** Panne réseau / timeout persistant après épuisement des retries. */
class EcoNetworkError extends EcoSDKError {}

/** Réponse d'erreur du serveur (5xx, 429...) persistante après les retries. */
class EcoApiError extends EcoSDKError {}

// ---------------------------------------------------------------------------
// Utilitaires internes
// ---------------------------------------------------------------------------

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** Statuts HTTP pour lesquels une nouvelle tentative a un sens (erreurs transitoires). */
const isRetryableStatus = (status) => status === 408 || status === 429 || status >= 500;

/** Le détail d'erreur FastAPI peut être une string (HTTPException) ou une liste (422). */
function extractDetail(body, fallback) {
  if (!body || body.detail === undefined) return fallback;
  if (typeof body.detail === 'string') return body.detail;
  try {
    return body.detail
      .map((d) => `${(d.loc || []).join('.')}: ${d.msg}`)
      .join('; ');
  } catch {
    return JSON.stringify(body.detail);
  }
}

// ---------------------------------------------------------------------------
// Classe principale
// ---------------------------------------------------------------------------

class EcoSDK {
  /**
   * @param {object}   options
   * @param {string}   options.apiKey            Clé API marchand (ex: "mch_live_xxx"). Obligatoire.
   * @param {string}   [options.baseUrl]         URL de la plateforme (défaut : http://localhost:8000).
   * @param {number}   [options.maxRetries=3]    Nombre de nouvelles tentatives après le 1er essai.
   * @param {number}   [options.retryDelayMs=300] Délai de base du backoff exponentiel.
   * @param {number}   [options.timeoutMs=5000]  Timeout par tentative.
   * @param {function} [options.onError]         Callback appelé en mode "arrière-plan" en cas d'échec final.
   * @param {function} [options.fetch]           Implémentation fetch injectable (tests, vieux Node).
   */
  constructor(options = {}) {
    const {
      apiKey,
      baseUrl = DEFAULT_BASE_URL,
      maxRetries = 3,
      retryDelayMs = 300,
      timeoutMs = 5000,
      onError = null,
      fetch: fetchImpl = globalThis.fetch,
    } = options;

    // Échec rapide (fail fast) : mieux vaut une erreur claire à l'initialisation
    // qu'un 401 obscur au premier appel -> réduit le TTFC.
    if (typeof apiKey !== 'string' || apiKey.trim() === '') {
      throw new EcoValidationError(
        "EcoSDK: l'option 'apiKey' est obligatoire. Exemple : new EcoSDK({ apiKey: 'mch_live_...' })"
      );
    }
    if (typeof fetchImpl !== 'function') {
      throw new EcoSDKError(
        "EcoSDK: aucun 'fetch' disponible. Utilisez Node.js >= 18 ou passez l'option { fetch }."
      );
    }

    this._apiKey = apiKey.trim();
    this._baseUrl = String(baseUrl).replace(/\/+$/, ''); // retire les "/" finaux
    this._maxRetries = maxRetries;
    this._retryDelayMs = retryDelayMs;
    this._timeoutMs = timeoutMs;
    this._onError = onError;
    this._fetch = fetchImpl;
  }

  // -------------------------------------------------------------------------
  // API publique
  // -------------------------------------------------------------------------

  /**
   * Enregistre un achat et son empreinte carbone. Attend la réponse du serveur
   * (avec retries automatiques en cas d'erreur transitoire).
   *
   * @param {{orderId: string, items: Array<{category: string, weightKg: number}>}} order
   * @returns {Promise<{success: boolean, orderId: string, carbonEmittedKg: number}>}
   */
  async trackPurchase(order) {
    this._validateOrder(order);
    return this._request('POST', '/v1/events/purchase', order, {
      // Clé d'idempotence = identifiant de commande. Elle permettra au serveur
      // de dédoublonner un achat renvoyé après une réponse perdue (voir README).
      'Idempotency-Key': order.orderId,
    });
  }

  /** Alias de trackPurchase, pour correspondre à l'exemple de l'énoncé du TP. */
  async trackCarbon(order) {
    return this.trackPurchase(order);
  }

  /**
   * Mode "fire-and-forget" : retourne IMMÉDIATEMENT (ne bloque jamais le tunnel
   * de paiement du marchand). L'envoi et les retries se font en arrière-plan ;
   * en cas d'échec définitif, l'erreur est transmise à `onError` (si fourni)
   * au lieu de provoquer une exception non gérée.
   *
   * La validation locale reste synchrone : une commande mal formée lève tout de suite.
   */
  trackPurchaseInBackground(order) {
    this._validateOrder(order);
    this.trackPurchase(order).catch((err) => {
      if (this._onError) {
        try {
          this._onError(err);
        } catch {
          /* un callback défaillant ne doit jamais faire planter le site marchand */
        }
      }
    });
  }

  /**
   * Statistiques cumulées du marchand identifié par la clé API.
   * @returns {Promise<{merchant: string, totalOrdersTracked: number, totalCarbonOffsetKg: number}>}
   */
  async getMerchantAnalytics() {
    return this._request('GET', '/v1/analytics/merchant');
  }

  // -------------------------------------------------------------------------
  // Internes
  // -------------------------------------------------------------------------

  /**
   * Validation côté client : renvoie une erreur lisible immédiatement, sans
   * aller-retour réseau, et garantit que ce qui entre dans la plateforme est
   * propre (standardisation des données).
   */
  _validateOrder(order) {
    const fail = (msg) => {
      throw new EcoValidationError(`EcoSDK: commande invalide — ${msg}`);
    };
    if (!order || typeof order !== 'object') fail("un objet { orderId, items } est attendu.");
    if (typeof order.orderId !== 'string' || order.orderId.trim() === '') {
      fail("'orderId' doit être une chaîne non vide.");
    }
    if (!Array.isArray(order.items) || order.items.length === 0) {
      fail("'items' doit être un tableau non vide.");
    }
    order.items.forEach((item, i) => {
      if (!item || typeof item.category !== 'string' || item.category.trim() === '') {
        fail(`items[${i}].category doit être une chaîne non vide.`);
      }
      if (typeof item.weightKg !== 'number' || !Number.isFinite(item.weightKg) || item.weightKg <= 0) {
        fail(`items[${i}].weightKg doit être un nombre strictement positif.`);
      }
    });
  }

  /**
   * Cœur du SDK : un appel HTTP + la politique de retry.
   *
   *  - Erreurs transitoires (réseau, timeout, 408, 429, 5xx) -> retry avec
   *    backoff exponentiel + jitter (évite que tous les clients réessaient
   *    au même instant et écrasent une plateforme qui se remet d'une panne).
   *  - Erreurs définitives (400, 401, 403, 422...) -> exception immédiate.
   */
  async _request(method, path, body, extraHeaders = {}) {
    const url = `${this._baseUrl}${path}`;
    const totalAttempts = this._maxRetries + 1;
    let lastError;

    for (let attempt = 1; attempt <= totalAttempts; attempt++) {
      let retryAfterMs = null;

      try {
        const response = await this._fetchWithTimeout(url, {
          method,
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'X-API-Key': this._apiKey,                 // authentification automatique
            'X-EcoSDK-Version': `js/${SDK_VERSION}`,   // télémétrie utile pour la gouvernance
            ...extraHeaders,
          },
          body: body !== undefined ? JSON.stringify(body) : undefined,
        });

        const payload = await response.json().catch(() => null);

        if (response.ok) return payload;

        const detail = extractDetail(payload, `HTTP ${response.status}`);

        // --- Erreurs définitives : on ne réessaie pas ---
        if (response.status === 401 || response.status === 403) {
          throw new EcoAuthError(`Authentification refusée : ${detail}`, { status: response.status, attempts: attempt });
        }
        if (!isRetryableStatus(response.status)) {
          throw new EcoValidationError(`Requête refusée par la plateforme : ${detail}`, {
            status: response.status,
            attempts: attempt,
          });
        }

        // --- Erreur transitoire côté serveur : on mémorise et on réessaie ---
        lastError = new EcoApiError(`Erreur serveur : ${detail}`, { status: response.status, attempts: attempt });
        const retryAfterHeader = Number(response.headers && response.headers.get && response.headers.get('retry-after'));
        if (Number.isFinite(retryAfterHeader) && retryAfterHeader > 0) {
          retryAfterMs = retryAfterHeader * 1000; // le serveur dicte son rythme
        }
      } catch (err) {
        // Les erreurs typées définitives remontent telles quelles
        if (err instanceof EcoAuthError || err instanceof EcoValidationError) throw err;
        if (err instanceof EcoApiError) {
          lastError = err;
        } else {
          // Erreur réseau / timeout (AbortError, ECONNREFUSED, DNS...)
          const isTimeout = err && err.name === 'AbortError';
          lastError = new EcoNetworkError(
            isTimeout
              ? `Timeout après ${this._timeoutMs} ms`
              : `Impossible de joindre la plateforme (${err && err.message ? err.message : err})`,
            { cause: err, attempts: attempt }
          );
        }
      }

      // Pas de pause après la dernière tentative
      if (attempt < totalAttempts) {
        const backoff = this._retryDelayMs * 2 ** (attempt - 1);       // 300, 600, 1200...
        const jitter = Math.random() * this._retryDelayMs;             // 0..300 ms
        await sleep(retryAfterMs ?? backoff + jitter);
      }
    }

    // Tentatives épuisées : on annote l'erreur finale avec le nombre d'essais
    lastError.attempts = totalAttempts;
    lastError.message += ` (échec après ${totalAttempts} tentatives)`;
    throw lastError;
  }

  /** fetch() + timeout via AbortController (fetch n'en a pas nativement). */
  async _fetchWithTimeout(url, options) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this._timeoutMs);
    try {
      return await this._fetch(url, { ...options, signal: controller.signal });
    } finally {
      clearTimeout(timer); // toujours nettoyer pour ne pas retenir le process Node
    }
  }
}

module.exports = {
  EcoSDK,
  EcoSDKError,
  EcoAuthError,
  EcoValidationError,
  EcoNetworkError,
  EcoApiError,
  SDK_VERSION,
};
