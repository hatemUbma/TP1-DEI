// Tests du SDK — lancer : node --test test/
const test = require('node:test');
const assert = require('node:assert');
const http = require('node:http');
const { EcoSDK, EcoAuthError, EcoValidationError, EcoNetworkError, EcoApiError } = require('../sdk/ecosdk');

/** Démarre un faux serveur ; `script` = liste de réponses {status, body} jouées dans l'ordre. */
function fakeServer(script) {
  const calls = [];
  const server = http.createServer((req, res) => {
    calls.push({ url: req.url, headers: req.headers });
    const step = script[Math.min(calls.length - 1, script.length - 1)];
    res.writeHead(step.status, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(step.body));
  });
  return new Promise((resolve) =>
    server.listen(0, () => resolve({ server, calls, url: `http://127.0.0.1:${server.address().port}` }))
  );
}

const ORDER = { orderId: 'ORD-1', items: [{ category: 'food', weightKg: 2 }] };
const OK = { status: 200, body: { success: true, orderId: 'ORD-1', carbonEmittedKg: 4 } };
const fast = { retryDelayMs: 5 }; // backoff court pour des tests rapides

test('envoie la clé API et réussit du premier coup', async () => {
  const { server, calls, url } = await fakeServer([OK]);
  const eco = new EcoSDK({ apiKey: 'k1', baseUrl: url, ...fast });
  const res = await eco.trackPurchase(ORDER);
  assert.strictEqual(res.carbonEmittedKg, 4);
  assert.strictEqual(calls[0].headers['x-api-key'], 'k1');
  assert.strictEqual(calls.length, 1);
  server.close();
});

test('réessaie après des 503 puis réussit', async () => {
  const { server, calls, url } = await fakeServer([
    { status: 503, body: { detail: 'down' } },
    { status: 503, body: { detail: 'down' } },
    OK,
  ]);
  const eco = new EcoSDK({ apiKey: 'k1', baseUrl: url, ...fast });
  const res = await eco.trackPurchase(ORDER);
  assert.strictEqual(res.success, true);
  assert.strictEqual(calls.length, 3);
  server.close();
});

test('401 -> EcoAuthError sans aucun retry', async () => {
  const { server, calls, url } = await fakeServer([{ status: 401, body: { detail: 'Clé invalide' } }]);
  const eco = new EcoSDK({ apiKey: 'bad', baseUrl: url, ...fast });
  await assert.rejects(() => eco.trackPurchase(ORDER), EcoAuthError);
  assert.strictEqual(calls.length, 1);
  server.close();
});

test('422 -> EcoValidationError sans retry', async () => {
  const { server, calls, url } = await fakeServer([{ status: 422, body: { detail: [{ loc: ['body', 'items'], msg: 'bad' }] } }]);
  const eco = new EcoSDK({ apiKey: 'k1', baseUrl: url, ...fast });
  await assert.rejects(() => eco.trackPurchase(ORDER), EcoValidationError);
  assert.strictEqual(calls.length, 1);
  server.close();
});

test('5xx persistant -> EcoApiError après maxRetries+1 tentatives', async () => {
  const { server, calls, url } = await fakeServer([{ status: 500, body: { detail: 'boom' } }]);
  const eco = new EcoSDK({ apiKey: 'k1', baseUrl: url, maxRetries: 2, ...fast });
  await assert.rejects(() => eco.trackPurchase(ORDER), (e) => e instanceof EcoApiError && e.attempts === 3);
  assert.strictEqual(calls.length, 3);
  server.close();
});

test('serveur injoignable -> EcoNetworkError', async () => {
  const eco = new EcoSDK({ apiKey: 'k1', baseUrl: 'http://127.0.0.1:1', maxRetries: 1, ...fast });
  await assert.rejects(() => eco.trackPurchase(ORDER), EcoNetworkError);
});

test('validation locale : aucune requête réseau pour une commande invalide', async () => {
  let called = false;
  const eco = new EcoSDK({ apiKey: 'k1', fetch: async () => { called = true; } });
  await assert.rejects(() => eco.trackPurchase({ orderId: '', items: [] }), EcoValidationError);
  assert.strictEqual(called, false);
});

test('apiKey manquante -> erreur à la construction', () => {
  assert.throws(() => new EcoSDK({}), EcoValidationError);
});

test('mode arrière-plan : retour immédiat, échec final transmis à onError', async () => {
  const { server, url } = await fakeServer([{ status: 500, body: { detail: 'boom' } }]);
  let reported;
  const eco = new EcoSDK({ apiKey: 'k1', baseUrl: url, maxRetries: 1, ...fast, onError: (e) => (reported = e) });
  const t0 = Date.now();
  eco.trackPurchaseInBackground(ORDER);
  assert.ok(Date.now() - t0 < 20, 'doit rendre la main immédiatement');
  await new Promise((r) => setTimeout(r, 200));
  assert.ok(reported instanceof EcoApiError);
  server.close();
});
