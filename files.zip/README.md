# TP — EcoSDK pour EcoMarketplace

## Arborescence
```
tp-sdk-ecomarketplace/
├── README.md
├── package.json
├── backend/            # API de la plateforme (FastAPI) — fournie
│   ├── main.py
│   └── requirements.txt
├── sdk/
│   └── ecosdk.js       # LE SDK (zéro dépendance, Node >= 18)
├── client-demo/
│   └── app.js          # site marchand simulé, refactorisé avec le SDK
└── test/
    └── ecosdk.test.js  # 9 tests (retries, erreurs typées, mode arrière-plan)
```

## Lancer
```bash
# Terminal 1 — backend
cd backend && pip install -r requirements.txt && uvicorn main:app --reload --port 8000

# Terminal 2 — démo marchand et tests
npm run demo
npm test
```

## Intégration marchande (3 lignes)
```js
const { EcoSDK } = require('./sdk/ecosdk');
const eco = new EcoSDK({ apiKey: 'mch_live_99x821a' });
await eco.trackPurchase({ orderId: 'ORD-12345', items: [{ category: 'electronics', weightKg: 1.2 }] });
```

## API du SDK
| Méthode | Rôle |
|---|---|
| `new EcoSDK({ apiKey, baseUrl?, maxRetries?, retryDelayMs?, timeoutMs?, onError? })` | Initialisation (échoue vite si `apiKey` absente) |
| `trackPurchase(order)` / `trackCarbon(order)` | Envoie un achat, avec retries automatiques |
| `trackPurchaseInBackground(order)` | Fire-and-forget : ne bloque jamais le paiement |
| `getMerchantAnalytics()` | Statistiques du marchand |

Erreurs typées : `EcoAuthError`, `EcoValidationError`, `EcoNetworkError`, `EcoApiError` (toutes héritent d'`EcoSDKError`).

## Politique de retry
Réessai (backoff exponentiel + jitter, respect de `Retry-After`) pour : erreurs réseau, timeout, 408, 429, 5xx.
Pas de retry pour : 400, 401, 403, 422 (erreurs définitives).

## Limite connue
Le backend fourni ne dédoublonne pas les `orderId` : si une réponse est perdue après traitement serveur,
un retry peut créer un doublon. Le SDK envoie déjà un header `Idempotency-Key` ; il suffit que le backend
l'exploite (ou rejette un `orderId` déjà vu) pour garantir un envoi « exactement une fois ».
