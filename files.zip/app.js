// SIMULATION : code présent sur le site e-commerce marchand (AVEC EcoSDK)
// Lancer : node client-demo/app.js   (backend démarré sur le port 8000)
// =========================================================================

// ---- Intégration : 2 lignes d'initialisation + 1 appel = "3 lignes" --------
const { EcoSDK, EcoAuthError, EcoValidationError } = require('../sdk/ecosdk');
const eco = new EcoSDK({ apiKey: 'mch_live_99x821a' });
//   await eco.trackPurchase({ orderId: 'ORD-1', items: [{ category: 'food', weightKg: 2 }] });
// ---------------------------------------------------------------------------

async function simulatePurchaseWithSDK() {
  // Le panier tel que le connaît le site marchand
  const order = {
    orderId: 'ORD-' + Math.floor(Math.random() * 10000),
    items: [
      { category: 'electronics', weightKg: 1.5 },
      { category: 'clothing', weightKg: 0.8 },
    ],
  };

  // 1) Appel simple : auth, JSON, retries et timeout sont gérés par le SDK
  try {
    const result = await eco.trackPurchase(order);
    console.log('[Avec SDK] Réponse de la plateforme :', result);
  } catch (error) {
    // Erreurs typées : pas besoin de décoder des codes HTTP à la main
    console.error(`[Avec SDK] ${error.name} : ${error.message}`);
  }

  // 2) Mode arrière-plan : ne bloque JAMAIS la validation du panier.
  //    L'envoi + les retries se font en tâche de fond, les échecs vont dans onError.
  const ecoBackground = new EcoSDK({
    apiKey: 'mch_live_99x821a',
    onError: (err) => console.warn(`[Arrière-plan] Achat non transmis : ${err.message}`),
  });
  ecoBackground.trackPurchaseInBackground({
    orderId: 'ORD-BG-' + Math.floor(Math.random() * 10000),
    items: [{ category: 'food', weightKg: 3 }],
  });
  console.log('[Arrière-plan] Le site marchand continue immédiatement, sans attendre.');

  // 3) Tableau de bord marchand (laisse le temps à l'envoi en arrière-plan)
  await new Promise((resolve) => setTimeout(resolve, 500));
  const stats = await eco.getMerchantAnalytics();
  console.log('[Avec SDK] Statistiques marchand :', stats);
}

async function demonstrateErrorHandling() {
  console.log('\n--- Démonstration de la gestion d\'erreurs ---');

  // Mauvaise clé API -> EcoAuthError, sans retry inutile
  try {
    await new EcoSDK({ apiKey: 'mch_live_FAUSSE' }).trackPurchase({
      orderId: 'ORD-X',
      items: [{ category: 'food', weightKg: 1 }],
    });
  } catch (error) {
    if (error instanceof EcoAuthError) console.log('Clé API refusée ->', error.message);
  }

  // Donnée invalide -> détectée localement, avant tout appel réseau
  try {
    await eco.trackPurchase({ orderId: 'ORD-Y', items: [{ category: 'food', weightKg: -2 }] });
  } catch (error) {
    if (error instanceof EcoValidationError) console.log('Commande invalide ->', error.message);
  }
}

simulatePurchaseWithSDK().then(demonstrateErrorHandling);
